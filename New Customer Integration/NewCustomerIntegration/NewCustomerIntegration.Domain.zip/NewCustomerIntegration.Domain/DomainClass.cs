﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewCustomerIntegration.Domain.Models;

namespace NewCustomerIntegration.Domain
{
    public partial class DomainClass
    {

    }
}
